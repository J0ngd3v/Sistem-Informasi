<?php

header("location: docs");